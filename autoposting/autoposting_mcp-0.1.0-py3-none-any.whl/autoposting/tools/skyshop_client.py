import httpx


class SkyshopApiError(Exception):
    def __init__(self, function: str, status_code: int, body: str):
        self.function = function
        self.status_code = status_code
        self.body = body
        super().__init__(f"Sky-shop API error in {function}: {status_code} — {body}")


class SkyshopClient:
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self._http = httpx.Client(timeout=30)

    def _check_response(self, function: str, response: httpx.Response) -> dict:
        """Parse Sky-shop response. Handles both formats:
        - {"status": "ok", "data": {...}}
        - {"response_code": 200, ...payload...}
        """
        if response.status_code != 200:
            raise SkyshopApiError(function, response.status_code, response.text)

        body = response.json()

        # Format 1: {"status": "ok", "data": {...}}
        if "status" in body:
            if body["status"] != "ok":
                raise SkyshopApiError(function, response.status_code, str(body))
            return body.get("data", body)

        # Format 2: {"response_code": 200, ...} — Sky-shop native
        rc = body.get("response_code", 200)
        if rc not in (200, 201):
            raise SkyshopApiError(function, rc, str(body))

        # Return body without response_code meta field
        body.pop("response_code", None)
        return body

    def call(self, function: str, params: dict | None = None) -> dict:
        """Call a Sky-shop API function via POST with form data."""
        response = self._http.post(
            self.base_url,
            data={"APIkey": self.api_key, "function": function, **(params or {})},
        )
        return self._check_response(function, response)

    def post(self, function: str, payload: dict) -> dict:
        """POST to Sky-shop API with form data payload."""
        response = self._http.post(
            self.base_url,
            data={"APIkey": self.api_key, "function": function, **payload},
        )
        return self._check_response(function, response)
