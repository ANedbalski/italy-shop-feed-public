from autoposting.server import mcp

mcp.run()
