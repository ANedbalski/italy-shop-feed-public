import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


class Config:
    SKYSHOP_API_KEY: str = os.environ.get("SKYSHOP_API_KEY", "")
    SKYSHOP_BASE_URL: str = os.getenv("SKYSHOP_BASE_URL", "https://www.italy-shop.eu/api")
    MAX_IMAGE_SIZE: int = int(os.getenv("MAX_IMAGE_SIZE", "1200"))
    WEBP_QUALITY: int = int(os.getenv("WEBP_QUALITY", "82"))
    OUTPUT_DIR: Path = Path(os.getenv("OUTPUT_DIR", "/tmp/autoposting"))
