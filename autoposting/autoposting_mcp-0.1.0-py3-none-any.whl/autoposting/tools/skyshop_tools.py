import xml.etree.ElementTree as ET
from pathlib import Path

import httpx

from autoposting.tools.skyshop_client import SkyshopClient


def get_orders(
    base_url: str,
    api_key: str,
    date_from: str = "",
    date_to: str = "",
    status: str = "",
) -> list[dict]:
    """Fetch orders from Sky-shop (all pages).

    Args:
        date_from: Start date in YYYY-MM-DD format (optional).
        date_to: End date in YYYY-MM-DD format (optional).
        status: Filter by status ID (optional).

    Returns list of orders with id, date, status, total, products, client info.
    """
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    all_orders: list[dict] = []
    start = 0
    limit = 50
    while True:
        params: dict = {"start": str(start), "limit": str(limit)}
        if date_from:
            params["dateFrom"] = date_from
        if date_to:
            params["dateTo"] = date_to
        if status:
            params["status"] = status
        data = client.call("getOrders", params)
        # Sky-shop returns orders as numbered keys ("0", "1", ...), not a list
        orders = [
            v for k, v in sorted(data.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 999)
            if k.isdigit() and isinstance(v, dict)
        ]
        if not orders:
            break
        all_orders.extend(orders)
        if len(orders) < limit:
            break
        start += limit
    # Client-side date filtering (Sky-shop dateFrom/dateTo may be unreliable)
    if date_from or date_to:
        filtered = []
        for o in all_orders:
            d = o.get("ord_date", "")[:10]
            if date_from and d < date_from:
                continue
            if date_to and d > date_to:
                continue
            filtered.append(o)
        return filtered
    return all_orders


def get_order_details(base_url: str, api_key: str, order_id: str) -> dict:
    """Fetch details of a single order from Sky-shop."""
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    return client.call("getOrders", {"orderID": order_id})


def get_skyshop_options(base_url: str, api_key: str) -> dict:
    """Fetch available product options (colors, sizes) from Sky-shop."""
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    return client.call("getOptions")


def get_categories(base_url: str, api_key: str) -> dict:
    """Fetch category tree from Sky-shop."""
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    return client.call("getCatsData")


def get_brand_catalog(brand: str, base_url: str, api_key: str) -> list[dict]:
    """Fetch existing products for a brand from Sky-shop."""
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    data = client.call("getProducts", {"search": brand})
    products = data.get("products", [])
    return [
        {
            "id": p.get("id"),
            "name": p.get("name"),
            "price": p.get("price"),
            "category": p.get("category"),
            "url": p.get("url"),
        }
        for p in products
    ]


def _build_product_xml(product: dict) -> str:
    """Build Sky-shop XML for addUpdateProducts."""
    root = ET.Element("products")
    item = ET.SubElement(root, "item")

    # Basic fields
    ET.SubElement(item, "prod_name_pl").text = product["name"]
    ET.SubElement(item, "prod_price").text = str(product["price"])
    ET.SubElement(item, "prd_name").text = product.get("producer", "")
    ET.SubElement(item, "prod_unit").text = "para"
    ET.SubElement(item, "prod_hidden").text = "0"
    ET.SubElement(item, "prod_amount").text = "0"

    # Shipping & dimensions
    ET.SubElement(item, "prod_shipping_time").text = str(product.get("shipping_time", 240))
    ET.SubElement(item, "prod_dimensions").text = product.get("dimensions", "B")
    ET.SubElement(item, "prod_orlen_paczka_dimensions").text = product.get("orlen_dimensions", "M")
    ET.SubElement(item, "prod_weight").text = str(product.get("weight", 1))
    ET.SubElement(item, "prod_symbol").text = product.get("symbol", "")

    # Description fields
    ET.SubElement(item, "prod_desc_pl").text = product.get("description", "")
    ET.SubElement(item, "prod_shortdesc_pl").text = product.get("short_description", "")
    ET.SubElement(item, "prod_info1_pl").text = product.get("info1", "")

    # SEO
    ET.SubElement(item, "prod_seotitle_pl").text = product.get("seo_title", "")
    ET.SubElement(item, "prod_seodesc_pl").text = product.get("seo_description", "")
    ET.SubElement(item, "prod_keywords_pl").text = product.get("keywords", "")

    # Options — separate entries to activate sizes and colors
    options_root = ET.SubElement(item, "options")

    seen_sizes = set()
    for variant in product.get("variants", []):
        for size in variant.get("sizes", []):
            rid = str(size["remote_id"])
            if rid not in seen_sizes:
                seen_sizes.add(rid)
                size_opts = ET.SubElement(options_root, "options")
                size_el = ET.SubElement(size_opts, "option")
                size_el.set("name", "Rozmiar obuwie")
                size_el.set("remote_id", rid)
                size_el.set("required", "1")
                size_el.text = size["value"]

    for variant in product.get("variants", []):
        color_opts = ET.SubElement(options_root, "options")
        color_el = ET.SubElement(color_opts, "option")
        color_el.set("name", "Kolor")
        color_el.set("remote_id", str(variant["color_remote_id"]))
        color_el.set("required", "1")
        color_el.text = variant["color"]

    return ET.tostring(root, encoding="unicode", xml_declaration=False)


def _upload_images(
    product_id: str,
    image_paths: list[str],
    base_url: str,
    api_key: str,
) -> list[dict]:
    """Upload images via addImagesToProduct (multipart, max 5 per call).
    Returns list of {img_id, img_src} for all uploaded images.
    """
    all_results = []
    # Sky-shop allows max 5 images per request
    for batch_start in range(0, len(image_paths), 5):
        batch = image_paths[batch_start:batch_start + 5]
        files = []
        for i, img_path in enumerate(batch):
            p = Path(img_path)
            files.append((f"images[{i}]", (p.name, p.read_bytes(), "image/webp")))

        response = httpx.post(
            base_url,
            data={
                "APIkey": api_key,
                "function": "addImagesToProduct",
                "productID": product_id,
                "mainImg": "",
            },
            files=files,
            timeout=120,
        )
        body = response.json()
        rc = body.get("response_code", 200)
        if rc not in (200, 201):
            raise RuntimeError(f"addImagesToProduct error: {body}")
        all_results.extend(body.get("result", []))

    return all_results


def _set_stock_combinations(
    product_id: str,
    variants: list[dict],
    client: SkyshopClient,
) -> None:
    """Set stock combinations (size×color with amount) via update XML."""
    root = ET.Element("products")
    item = ET.SubElement(root, "item")
    ET.SubElement(item, "prod_id").text = product_id

    options_root = ET.SubElement(item, "options")
    for variant in variants:
        for size in variant.get("sizes", []):
            combo = ET.SubElement(options_root, "options")
            combo.set("amount", str(size.get("amount", 0)))
            combo.set("ean", "")
            combo.set("barcode", "")
            combo.set("symbol", "")

            size_el = ET.SubElement(combo, "option")
            size_el.set("name", "Rozmiar obuwie")
            size_el.set("remote_id", str(size["remote_id"]))
            size_el.text = size["value"]

            color_el = ET.SubElement(combo, "option")
            color_el.set("name", "Kolor")
            color_el.set("remote_id", str(variant["color_remote_id"]))
            color_el.text = variant["color"]

    xml_payload = ET.tostring(root, encoding="unicode", xml_declaration=False)
    client.post("addUpdateProducts", {
        "importType": "update",
        "xml": xml_payload,
    })


def _set_categories(
    product_id: str,
    category_ids: list[str],
    base_url: str,
    api_key: str,
) -> None:
    """Assign product to categories via productCategoryControl."""
    client = SkyshopClient(base_url=base_url, api_key=api_key)
    client.post("productCategoryControl", {
        "productID": product_id,
        "categoryID": ",".join(category_ids),
        "action": "overwrite",
    })


def _link_images_to_colors(
    product_id: str,
    color_image_map: dict[str, int],
    product_data: dict,
    base_url: str,
    api_key: str,
) -> None:
    """Link uploaded image IDs to color options via addUpdateProducts update.

    color_image_map: {"Beżowy": img_id, "Karmel": img_id}
    """
    # Build minimal XML to update option image links
    root = ET.Element("products")
    item = ET.SubElement(root, "item")
    ET.SubElement(item, "prod_id").text = product_id

    options_root = ET.SubElement(item, "options")
    for color_name, img_id in color_image_map.items():
        color_opts = ET.SubElement(options_root, "options")
        color_el = ET.SubElement(color_opts, "option")
        color_el.set("name", "Kolor")
        color_el.set("rel_img_id", str(img_id))
        color_el.text = color_name

    xml_payload = ET.tostring(root, encoding="unicode", xml_declaration=False)

    client = SkyshopClient(base_url=base_url, api_key=api_key)
    client.post("addUpdateProducts", {
        "importType": "update",
        "xml": xml_payload,
    })


def publish_product(
    product: dict,
    image_paths: list[str],
    base_url: str,
    api_key: str,
) -> dict:
    """Publish a product to Sky-shop.

    Steps:
    1. addUpdateProducts — create product with XML (descriptions, options, SEO)
    2. addImagesToProduct — upload images via multipart
    3. productCategoryControl — assign correct categories
    4. setProductAmount — set amount to 0 (stock managed per variant)
    5. Link images to color variants (if color_image_map provided)

    product dict fields:
        name, description, short_description, price,
        producer, seo_title, seo_description, keywords, info1,
        symbol, weight, shipping_time, dimensions, orlen_dimensions,
        category_ids: ["19", "33"],  # Klapki + Wiosna/Lato 2026
        variants: [{"color": "Beżowy", "color_remote_id": "47",
                     "sizes": [{"value": "36", "remote_id": "40"}, ...]}],
        color_image_map: {"Beżowy": 0, "Karmel": 5}  # index into image_paths
    """
    client = SkyshopClient(base_url=base_url, api_key=api_key)

    # Step 1: Create product with XML
    xml_payload = _build_product_xml(product)
    result = client.post("addUpdateProducts", {
        "importType": "add",
        "xml": xml_payload,
    })

    products = result.get("stats", {}).get("products", [])
    if not products:
        return {"error": "No product created", "raw": result}

    product_id = str(products[0]["prod_id"])

    # Step 2: Update with stock combinations (size×color with amount)
    # Must be separate request — combining with step 1 deactivates sizes
    _set_stock_combinations(product_id, product.get("variants", []), client)

    # Step 3: Upload images
    uploaded_images = _upload_images(product_id, image_paths, base_url, api_key)

    # Step 4: Assign categories
    category_ids = product.get("category_ids", [])
    if category_ids:
        _set_categories(product_id, category_ids, base_url, api_key)

    # Step 5: Set product amount to 0 (stock shown per variant)
    client.post("setProductAmount", {
        "productID": product_id,
        "amount": "0",
    })

    # Step 6: Link images to colors (if mapping provided)
    color_image_map = product.get("color_image_map", {})
    if color_image_map and uploaded_images:
        resolved_map = {}
        for color_name, img_index in color_image_map.items():
            if img_index < len(uploaded_images):
                resolved_map[color_name] = uploaded_images[img_index]["img_id"]
        if resolved_map:
            _link_images_to_colors(
                product_id, resolved_map, {}, base_url, api_key
            )

    return {
        "product_id": product_id,
        "status": products[0].get("status", "unknown"),
        "images_uploaded": len(uploaded_images),
        "uploaded_images": uploaded_images,
        "categories": category_ids,
    }
