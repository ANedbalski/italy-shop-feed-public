from mcp.server.fastmcp import FastMCP
from autoposting.config import Config
from autoposting.tools.images import process_images as _process_images
from autoposting.tools.skyshop_tools import (
    get_orders as _get_orders,
    get_order_details as _get_order_details,
    get_skyshop_options as _get_skyshop_options,
    get_categories as _get_categories,
    get_brand_catalog as _get_brand_catalog,
    publish_product as _publish_product,
)

mcp = FastMCP(
    "autoposting",
    instructions="Product publishing tools for italy-shop.eu",
)


@mcp.tool()
def get_orders(date_from: str = "", date_to: str = "", status: str = "") -> list[dict]:
    """Get orders from italy-shop.eu Sky-shop.
    Args:
        date_from: Start date YYYY-MM-DD (optional).
        date_to: End date YYYY-MM-DD (optional).
        status: Filter by status ID (optional).
    Returns list of orders with details.
    """
    config = Config()
    return _get_orders(
        base_url=config.SKYSHOP_BASE_URL,
        api_key=config.SKYSHOP_API_KEY,
        date_from=date_from,
        date_to=date_to,
        status=status,
    )


@mcp.tool()
def get_order_details(order_id: str) -> dict:
    """Get details of a single order from italy-shop.eu.
    Args:
        order_id: The Sky-shop order ID.
    Returns order details including products, client, payment.
    """
    config = Config()
    return _get_order_details(
        base_url=config.SKYSHOP_BASE_URL,
        api_key=config.SKYSHOP_API_KEY,
        order_id=order_id,
    )


@mcp.tool()
def process_images(paths: list[str]) -> list[str]:
    """Resize images and convert to WebP for upload.
    Takes a list of image file paths. Resizes to MAX_IMAGE_SIZE px on the longest
    side (preserves aspect ratio, no crop). Converts to WebP.
    Returns list of paths to processed .webp files.
    """
    config = Config()
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return _process_images(
        paths,
        max_size=config.MAX_IMAGE_SIZE,
        quality=config.WEBP_QUALITY,
        output_dir=str(config.OUTPUT_DIR),
    )


@mcp.tool()
def get_skyshop_options() -> dict:
    """Get available product options (colors, sizes) from Sky-shop.
    Returns a dict with available option groups and their values.
    """
    config = Config()
    return _get_skyshop_options(base_url=config.SKYSHOP_BASE_URL, api_key=config.SKYSHOP_API_KEY)


@mcp.tool()
def get_categories() -> dict:
    """Get category tree from Sky-shop.
    Returns nested category structure with IDs, names, and product counts.
    Use this to find the correct category_id before publishing.
    Always call this before publish_product to get up-to-date categories.
    """
    config = Config()
    return _get_categories(base_url=config.SKYSHOP_BASE_URL, api_key=config.SKYSHOP_API_KEY)


@mcp.tool()
def get_brand_catalog(brand: str) -> list[dict]:
    """Get existing products for a brand from italy-shop.eu.
    Returns list of products (id, name, price, category, url).
    """
    config = Config()
    return _get_brand_catalog(brand, base_url=config.SKYSHOP_BASE_URL, api_key=config.SKYSHOP_API_KEY)


@mcp.tool()
def publish_product(product: dict, image_paths: list[str]) -> dict:
    """Publish a product to italy-shop.eu via Sky-shop API.
    product dict must contain: name, description, price, category_id,
    seo_title, seo_description, variants (list of {color, sizes}).
    image_paths: list of paths to WebP files (use process_images first).
    Returns: {product_id, url}
    """
    config = Config()
    return _publish_product(
        product=product,
        image_paths=image_paths,
        base_url=config.SKYSHOP_BASE_URL,
        api_key=config.SKYSHOP_API_KEY,
    )


def main():
    mcp.run()
