from pathlib import Path
from PIL import Image


def process_images(
    paths: list[str],
    max_size: int = 1200,
    quality: int = 82,
    output_dir: str | None = None,
) -> list[str]:
    """Resize images and convert to WebP.

    Resizes to fit within max_size on the longest side (no crop).
    Sky-shop generates thumbnails itself — we only compress for upload speed.
    """
    results = []
    for path_str in paths:
        src = Path(path_str)
        out_dir = Path(output_dir) if output_dir else src.parent
        out_path = out_dir / f"{src.stem}.webp"

        img = Image.open(src)
        img.thumbnail((max_size, max_size), Image.LANCZOS)
        img.save(out_path, "WebP", quality=quality, optimize=True)
        results.append(str(out_path))

    return results
